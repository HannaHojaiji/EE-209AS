package com.example;

public class PhoneWatchClass {
    private PhoneWatchClass() {
    }

    public static final String WATCH_TO_PHONE_MESSAGE_PATH = "/watchToPhone";
    public static final String PHONE_TO_WATCH_MESSAGE_PATH = "/phoneToWatch";
}
