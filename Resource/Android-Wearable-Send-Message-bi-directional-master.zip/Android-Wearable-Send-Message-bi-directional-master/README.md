# Android-Wearable-Send-Message-bi-directional
A template to show how to perform send message between wearable and phone/tablet in both directions


You can press the fab button to send any string in the editText field to the watch when the watch app is opened.
On the watch, you can press the send button to send the text on the top of the watch screen to the phone when the phone app is opened.

Phone Preview:
![Output sample](https://github.com/jeffreyliu8/Android-Wearable-Send-Message-bi-directional/blob/master/phonePreview.png)

Watch Preview:
![Output sample](https://github.com/jeffreyliu8/Android-Wearable-Send-Message-bi-directional/blob/master/watchPreview.png)
