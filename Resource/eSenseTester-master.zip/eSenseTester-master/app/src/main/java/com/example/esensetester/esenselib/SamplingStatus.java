package com.example.esensetester.esenselib;

/**
 * Status of sensor sampling
 */

enum SamplingStatus {
    STARTED,
    DEVICE_DISCONNECTED,
    ERROR
}
